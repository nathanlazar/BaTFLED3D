# Some tests using the testthat package

expect_that(2 ^ 2, equals(4))
expect_that(2 + 2 == 4, is_true())
expect_that(2 == 1, is_false())
expect_that(1, is_a('numeric'))
expect_that(print('Hello World!'), prints_text('Hello World!'))
expect_that(log('a'), throws_error())
expect_that(factorial(4), equals(24))
expect_false(factorial(3)==5)
expect_warning(log(-1))
expect_that(factorial(4), equals(24))
