# Some tests using the testthat package

# if(model.params$lower.bnd)
#   expect_that(sum((trained$lower.bnd[-1]-trained$lower.bnd[-reps])<0), equals(0))
# 
# input.data <- input_data$new(mode1.X = matrix(rnorm(30), nrow=3, ncol=10),
#                              mode2.X = matrix(rnorm(36), nrow=4, ncol=9), 
#                              mode3.X = matrix(rnorm(40), nrow=5, ncol=8),
#                              resp = array(rnorm(60), dim=c(3,4,5)))
# expect_that(input.data$mode1.X, is_a('matrix'))
# expect_equal(nrow(input.data$mode1.X), dim(input.data$resp)[[1]])
# 
# # Tests of get_data_params and mk_toy
# cp.params <- get_data_params(list('decomp=CP'))
# cp.toy <- mk_toy(data.params)
# expect_that(cp.params$R > 0, is_true())
# expect_that(is.null(cp.params$R1), is_true())
# expect_that(cp.toy$core, is_a('array'))
# expect_that(identical(cp.toy$resp, array(0,dim=c(cp.params$m1.rows, cp.params$m2.rows, cp.params$m3.rows))), 
#             is_false())
# 
# tucker.params <- get_data_params(list('decomp=Tucker'))
# tucker.toy <- mk_toy(data.params)
# expect_that(tucker.params$R1 > 0, is_true())
# expect_that(is.null(tucker.params$R), is_true())
