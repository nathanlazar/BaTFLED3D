# Sandbox to work out ideas

# Simulation to see what the overlap of the number of predictors shared across
# cross-validation folds would be if the predictors were getting selected
# at random

# For DREAM7 data:
n_cl_preds <- 734
n_dr_preds <- 434

folds <- 10
n_cl_per_fold <- c(100,110,101,103,105,106,106,103,105,104)
n_dr_per_fold <- c(78,85,85,80,81,79,90,94,88,90)

cl_selected <- c(503,274,137,66,32,14,9,5,2,1)
dr_selected <- c(348,228,137,66,35,20,11,4,1,0)

cl_lapping <- matrix(0, 1000, 10)
dr_lapping <- matrix(0, 1000, 10)

for(rep in 1:1000) {
  cl_chosen <- matrix(0, n_cl_preds, folds)
  dr_chosen <- matrix(0, n_cl_preds, folds)
  for(fold in 1:folds) {
    cl_chosen[sample(1:n_cl_preds, n_cl_per_fold[fold]), fold] <- 1
    dr_chosen[sample(1:n_dr_preds, n_dr_per_fold[fold]), fold] <- 1
  }
  
  for(i in 1:folds) {
    cl_n <- sum(rowSums(cl_chosen) >= i)
    dr_n <- sum(rowSums(dr_chosen) >= i)
    cl_lapping[rep, i] <- cl_n
    dr_lapping[rep, i] <- dr_n
    # print(sprintf('Overlapping %d folds: %d (%.2f%%)', i, n, n/n_cl_preds*100))
  }
}

cl_means <- apply(cl_lapping, 2, mean)
cl_sds <- apply(cl_lapping, 2, sd)
cl_diff <- abs(cl_means-cl_selected)
cl_lt <- cl_selected < cl_means
cl_p <- 2*((1-cl_lt) * colSums(sweep(cl_lapping, 2, cl_means+cl_diff, FUN='>'))/1000 +
  (1*cl_lt) * colSums(sweep(cl_lapping, 2, cl_means-cl_diff, FUN='<'))/1000)

dr_means <- apply(dr_lapping, 2, mean)
dr_sds <- apply(dr_lapping, 2, sd)
dr_diff <- abs(dr_means-dr_selected)
dr_lt <- dr_selected < dr_means
dr_p <- 2*((1-dr_lt) * colSums(sweep(dr_lapping, 2, dr_means+dr_diff, FUN='>'))/1000 +
             (1*dr_lt) * colSums(sweep(dr_lapping, 2, dr_means-dr_diff, FUN='<'))/1000)
